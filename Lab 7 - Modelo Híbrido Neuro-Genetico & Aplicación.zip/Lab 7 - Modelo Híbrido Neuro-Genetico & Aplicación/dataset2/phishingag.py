import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import random, time, warnings
warnings.filterwarnings("ignore")

# =====================================================
# 1. RED NEURONAL (idéntica a tu versión original)
# =====================================================
def ReLu(x):        return np.maximum(0, x)
def ReLu_deriv(x):  return (x > 0).astype(float)
def sigmoide(x):    return 1.0 / (1.0 + np.exp(-x))
def sigmoide_deriv(x):
    s = sigmoide(x); return s * (1.0 - s)

DERIVADAS = {ReLu: ReLu_deriv, sigmoide: sigmoide_deriv}

def mse(T, Yhat):       return np.mean(0.5 * (T - Yhat) ** 2)
def mse_deriv(T, Yhat): return -(T - Yhat)

class Capa:
    def __init__(self, entradas, neuronas, activacion, bias=False, pesos=None):
        self.activacion = activacion
        self.activacion_deriv = DERIVADAS[activacion]
        self.bias = bias
        if pesos is not None:
            self.pesos = np.array(pesos, dtype=float)
        else:
            filas = entradas + 1 if bias else entradas
            self.pesos = np.random.rand(filas, neuronas) - 0.5

    def _aumentar(self, X):
        return np.hstack([X, np.ones((X.shape[0], 1))]) if self.bias else X

    def feed_forward(self, X):
        self.entrada_aum = self._aumentar(X)
        self.N = self.entrada_aum @ self.pesos
        self.salida = self.activacion(self.N)
        return self.salida

    def backward(self, T=None, delta_siguiente=None, W_siguiente=None, es_salida=False):
        if es_salida:
            self.delta = mse_deriv(T, self.salida) * self.activacion_deriv(self.N)
        else:
            self.delta = (delta_siguiente @ W_siguiente.T) * self.activacion_deriv(self.N)
        self.grad = self.entrada_aum.T @ self.delta
        return self.delta

    def actualizar(self, alpha, m=1):
        self.pesos -= alpha * (self.grad / m)

class Red:
    def __init__(self, capas): self.capas = capas

    def feedforward(self, X):
        a = X
        for c in self.capas: a = c.feed_forward(a)
        return a

    def backpropagation(self, T, alpha):
        n = len(self.capas); m = T.shape[0]
        for i in reversed(range(n)):
            capa = self.capas[i]
            if i == n - 1:
                capa.backward(T=T, es_salida=True)
            else:
                sig = self.capas[i + 1]
                W_sig = sig.pesos[:-1, :] if sig.bias else sig.pesos
                capa.backward(delta_siguiente=sig.delta, W_siguiente=W_sig)
        for c in self.capas: c.actualizar(alpha, m=m)

    def train(self, X, T, epocas, tol, alpha, cada=500, verbose=True):
        loss = float("inf")
        for epoca in range(1, epocas + 1):
            YH = self.feedforward(X)
            loss = mse(T, YH)
            if verbose and epoca % cada == 0:
                print(f"  Epoca {epoca} | MSE: {loss:.6f}")
            if not np.isfinite(loss): return
            if loss <= tol:
                if verbose:
                    print(f"  Epoca {epoca} | MSE: {loss:.6f} (tolerancia alcanzada)")
                return
            self.backpropagation(T, alpha)
        if verbose:
            print(f"  Epoca {epocas} | MSE final: {loss:.6f}")

    def predecir(self, X): return self.feedforward(X)

# =====================================================
# 2. UTILIDADES DEL ALGORITMO GENÉTICO
# =====================================================
ESPACIO = {
    "num_neuronas_ocultas": (5, 40),
    "alpha":                (0.05, 1.0),
    "max_features":         (50, 300),
    "ngram_min":            (1, 4),
    "ngram_max":            (2, 6),
    "usar_bias":            (0, 1),
    "activacion_oculta":    (0, 1),   # 0=sigmoide, 1=ReLu
}

def reparar(ind):
    ind = dict(ind)
    ind["num_neuronas_ocultas"] = int(np.clip(round(ind["num_neuronas_ocultas"]), 5, 40))
    ind["alpha"]                = float(np.clip(ind["alpha"], 0.05, 1.0))
    ind["max_features"]         = int(np.clip(round(ind["max_features"]), 50, 300))
    ind["ngram_min"]            = int(np.clip(round(ind["ngram_min"]), 1, 4))
    ind["ngram_max"]            = int(np.clip(round(ind["ngram_max"]), 2, 6))
    if ind["ngram_max"] < ind["ngram_min"]:
        ind["ngram_max"] = ind["ngram_min"]
    ind["usar_bias"]            = int(np.clip(round(ind["usar_bias"]), 0, 1))
    ind["activacion_oculta"]    = int(np.clip(round(ind["activacion_oculta"]), 0, 1))
    return ind

def inicializar_poblacion(tam):
    pob = []
    for _ in range(tam):
        ind = {
            "num_neuronas_ocultas": np.random.randint(5, 41),
            "alpha":                float(np.exp(np.random.uniform(np.log(0.05), np.log(1.0)))),
            "max_features":         np.random.randint(50, 301),
            "ngram_min":            np.random.randint(1, 4),
            "ngram_max":            np.random.randint(2, 7),
            "usar_bias":            np.random.randint(0, 2),
            "activacion_oculta":    np.random.randint(0, 2),
        }
        pob.append(reparar(ind))
    return pob

def seleccion_torneo(pob, fits, k=3):
    idxs = np.random.choice(len(pob), k, replace=False)
    return dict(pob[idxs[np.argmax([fits[i] for i in idxs])]])

def cruzar(p1, p2):
    return {k: (p1[k] if np.random.rand() < 0.5 else p2[k]) for k in p1}

def mutar(ind, prob=0.25):
    ind = dict(ind)
    if np.random.rand() < prob: ind["num_neuronas_ocultas"] += np.random.randint(-5, 6)
    if np.random.rand() < prob: ind["alpha"] *= float(np.exp(np.random.normal(0, 0.35)))
    if np.random.rand() < prob: ind["max_features"] += np.random.randint(-30, 31)
    if np.random.rand() < prob: ind["ngram_min"] += np.random.choice([-1, 1])
    if np.random.rand() < prob: ind["ngram_max"] += np.random.choice([-1, 1])
    if np.random.rand() < prob*0.5: ind["usar_bias"]         = 1 - ind["usar_bias"]
    if np.random.rand() < prob*0.5: ind["activacion_oculta"] = 1 - ind["activacion_oculta"]
    return reparar(ind)

def algoritmo_genetico(pob, evaluar, generaciones, elitismo=2):
    historial, mejor_global, mejor_fit = [], None, -1.0
    cache_eval = {}
    for gen in range(generaciones):
        print(f"\n===== Generación {gen+1}/{generaciones} =====")
        fits = []
        for i, ind in enumerate(pob):
            key = tuple(sorted(ind.items()))
            if key in cache_eval:
                f = cache_eval[key]
            else:
                t0 = time.time(); f = evaluar(ind)
                cache_eval[key] = f
                print(f"  Ind {i+1:2d} | fit={f:.4f} | {time.time()-t0:5.1f}s | {ind}")
            fits.append(f)
        orden = np.argsort(fits)[::-1]
        if fits[orden[0]] > mejor_fit:
            mejor_fit = fits[orden[0]]; mejor_global = dict(pob[orden[0]])
        historial.append({"gen": gen+1, "mejor": fits[orden[0]],
                          "prom": float(np.mean(fits)), "peor": float(np.min(fits))})
        print(f"  >> Mejor gen: {fits[orden[0]]:.4f} | Prom: {np.mean(fits):.4f} | Global: {mejor_fit:.4f}")

        nueva = [dict(pob[i]) for i in orden[:elitismo]]
        while len(nueva) < len(pob):
            p1 = seleccion_torneo(pob, fits)
            p2 = seleccion_torneo(pob, fits)
            nueva.append(mutar(cruzar(p1, p2)))
        pob = nueva
    return mejor_global, mejor_fit, historial

# =====================================================
# 3. FITNESS: entrena una red y devuelve accuracy en validación
# =====================================================
def construir_red(ind, n_entradas):
    act = sigmoide if ind["activacion_oculta"] == 0 else ReLu
    return Red([
        Capa(entradas=n_entradas, neuronas=ind["num_neuronas_ocultas"],
             activacion=act, bias=bool(ind["usar_bias"])),
        Capa(entradas=ind["num_neuronas_ocultas"], neuronas=1,
             activacion=sigmoide, bias=True),
    ])

def evaluar_individuo(ind, X_raw_tr, T_tr, X_raw_va, T_va, cache_vec, epocas, tol):
    ngram = (ind["ngram_min"], ind["ngram_max"])
    key = (ngram, ind["max_features"])
    if key not in cache_vec:
        vec = TfidfVectorizer(analyzer="char_wb", ngram_range=ngram,
                              max_features=ind["max_features"])
        vec.fit(X_raw_tr)              # solo con train → sin leakage
        cache_vec[key] = vec
    vec = cache_vec[key]
    X_tr = vec.transform(X_raw_tr).toarray()
    X_va = vec.transform(X_raw_va).toarray()

    np.random.seed(42)                 # pesos deterministas por individuo
    red = construir_red(ind, X_tr.shape[1])
    red.train(X_tr, T_tr, epocas=epocas, tol=tol, alpha=ind["alpha"],
              cada=epocas+1, verbose=False)
    pred = red.predecir(X_va)
    if not np.all(np.isfinite(pred)): return 0.0
    return float(np.mean((pred >= 0.5).astype(float) == T_va))

# =====================================================
# 4. FLUJO PRINCIPAL
# =====================================================
if __name__ == "__main__":
    np.random.seed(0); random.seed(0)

    print("Cargando dataset...")
    df = pd.read_csv("phishing_site_urls.csv")
    print(f"Dataset original: {len(df)} URLs")

    N_MUESTRA = 8000
    df_m = df.sample(n=N_MUESTRA, random_state=42).reset_index(drop=True)
    df_m["Target"] = df_m["Label"].apply(lambda x: 1.0 if x == "bad" else 0.0)

    # Split: 70 % train | 10 % val | 20 % test
    X_raw_tr, X_raw_te, T_tr_full, T_te = train_test_split(
        df_m["URL"].values, df_m["Target"].values.reshape(-1, 1),
        test_size=0.20, random_state=42)
    X_raw_tr, X_raw_va, T_tr, T_va = train_test_split(
        X_raw_tr, T_tr_full, test_size=0.125, random_state=42)

    print(f"Train: {len(X_raw_tr)} | Val: {len(X_raw_va)} | Test: {len(X_raw_te)}")

    cache_vec = {}
    EPOCAS_GA, TOL_GA = 400, 0.02

    def evaluar(ind):
        try:
            return evaluar_individuo(ind, X_raw_tr, T_tr, X_raw_va, T_va,
                                     cache_vec, EPOCAS_GA, TOL_GA)
        except Exception as e:
            print(f"  [ERROR] {e}"); return 0.0

    print("\n" + "="*60); print("INICIANDO ALGORITMO GENÉTICO"); print("="*60)
    t0 = time.time()
    pob = inicializar_poblacion(12)
    mejor, mejor_fit, hist = algoritmo_genetico(pob, evaluar, generaciones=10)
    print(f"\nTiempo total GA: {time.time() - t0:.1f}s")

    print("\n" + "="*60); print("MEJORES HIPERPARÁMETROS"); print("="*60)
    for k, v in mejor.items(): print(f"  {k}: {v}")
    print(f"  Fitness (acc validación): {mejor_fit:.4f}")

    # --- Reentreno final con train + val ---
    print("\nReentrenando mejor configuración (train+val, 3000 épocas)...")
    X_raw_full = np.concatenate([X_raw_tr, X_raw_va])
    T_full     = np.concatenate([T_tr, T_va])

    vec_f = TfidfVectorizer(analyzer="char_wb",
                            ngram_range=(mejor["ngram_min"], mejor["ngram_max"]),
                            max_features=mejor["max_features"])
    vec_f.fit(X_raw_full)
    X_tr_f = vec_f.transform(X_raw_full).toarray()
    X_te_f = vec_f.transform(X_raw_te).toarray()

    np.random.seed(42)
    red_f = construir_red(mejor, X_tr_f.shape[1])
    red_f.train(X_tr_f, T_full, epocas=3000, tol=1e-4,
                alpha=mejor["alpha"], cada=500)

    acc_opt = float(np.mean((red_f.predecir(X_te_f) >= 0.5).astype(float) == T_te))
    print(f"\n>>> Exactitud OPTIMIZADA en test: {acc_opt*100:.2f}%")

    # --- Baseline original para comparar ---
    print("\n" + "="*60); print("COMPARACIÓN vs CONFIGURACIÓN ORIGINAL"); print("="*60)
    vec_b = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), max_features=100)
    vec_b.fit(X_raw_full)
    X_tr_b = vec_b.transform(X_raw_full).toarray()
    X_te_b = vec_b.transform(X_raw_te).toarray()
    np.random.seed(0)
    red_b = Red([Capa(100, 15, sigmoide, bias=True),
                 Capa(15,  1, sigmoide, bias=True)])
    red_b.train(X_tr_b, T_full, epocas=3000, tol=1e-4, alpha=0.5, cada=1000, verbose=True)
    acc_base = float(np.mean((red_b.predecir(X_te_b) >= 0.5).astype(float) == T_te))
    print(f"\nBaseline    : {acc_base*100:.2f}%")
    print(f"Optimizado  : {acc_opt*100:.2f}%")
    print(f"Mejora      : {(acc_opt - acc_base)*100:+.2f} pp")

    # --- URL personalizada ---
    print("\n" + "="*50); print("PRUEBA CON URL PERSONALIZADA"); print("="*50)
    mi_url = "https://wikipedia.org"
    score = float(red_f.predecir(vec_f.transform([mi_url]).toarray())[0][0])
    print(f"URL: {mi_url}\nScore: {score:.3f}")
    print("VEREDICTO: MALICIOSA 🚨" if score >= 0.5 else "VEREDICTO: SEGURA ✅")