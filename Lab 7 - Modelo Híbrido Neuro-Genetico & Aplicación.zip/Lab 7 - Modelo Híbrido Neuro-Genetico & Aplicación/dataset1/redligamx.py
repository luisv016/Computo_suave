import numpy as np
import csv

# ============================================================
# ACTIVACIONES
# ============================================================
def ReLu(x):
    return np.maximum(0, x)

def ReLu_deriv(x):
    return (x > 0).astype(float)

def sigmoide(x):
    return 1.0 / (1.0 + np.exp(-x))

def sigmoide_deriv(x):
    s = sigmoide(x)
    return s * (1.0 - s)

def softmax(x):
    x_s = x - np.max(x, axis=1, keepdims=True)   # estabilidad numérica
    e = np.exp(x_s)
    return e / np.sum(e, axis=1, keepdims=True)

DERIVADAS = {ReLu: ReLu_deriv, sigmoide: sigmoide_deriv, softmax: None}


# ============================================================
# PÉRDIDAS Y MÉTRICAS
# ============================================================
def cross_entropy(T, Yhat):
    return -np.mean(np.sum(T * np.log(Yhat + 1e-12), axis=1))

def exactitud(T, Yhat):
    return np.mean(np.argmax(Yhat, axis=1) == np.argmax(T, axis=1))


# ============================================================
# CAPA
# ============================================================
class Capa:
    def __init__(self, entradas, neuronas, activacion, bias=False, pesos=None):
        self.activacion = activacion
        self.bias = bias
        self.es_softmax = (activacion is softmax)

        if pesos is not None:
            self.pesos = np.array(pesos, dtype=float)
        else:
            filas = entradas + 1 if bias else entradas
            # He para ReLU, Xavier para el resto
            if activacion is ReLu:
                scale = np.sqrt(2.0 / entradas)
            else:
                scale = np.sqrt(1.0 / entradas)
            self.pesos = np.random.randn(filas, neuronas) * scale

    def _aumentar(self, X):
        if self.bias:
            return np.hstack([X, np.ones((X.shape[0], 1))])
        return X

    def feed_forward(self, X):
        self.entrada_aum = self._aumentar(X)
        self.N = self.entrada_aum @ self.pesos
        self.salida = self.activacion(self.N)
        return self.salida

    def backward(self, T=None, delta_siguiente=None, W_siguiente=None, es_salida=False):
        if es_salida and self.es_softmax:
            # Derivada combinada softmax + cross-entropy
            self.delta = self.salida - T
        elif es_salida:
            # Sigmoide + MSE (compatibilidad)
            self.delta = -(T - self.salida) * DERIVADAS[self.activacion](self.N)
        else:
            deriv = DERIVADAS[self.activacion](self.N)
            self.delta = (delta_siguiente @ W_siguiente.T) * deriv

        self.grad = self.entrada_aum.T @ self.delta
        return self.delta

    def actualizar(self, alpha, m=1, l2=0.0):
        if l2 > 0:
            self.pesos -= alpha * (self.grad / m + l2 * self.pesos)
        else:
            self.pesos -= alpha * (self.grad / m)


# ============================================================
# RED
# ============================================================
class Red:
    def __init__(self, capas):
        self.capas = capas

    def feedforward(self, X):
        a = X
        for c in self.capas:
            a = c.feed_forward(a)
        return a

    def backpropagation(self, T, alpha, l2=0.0):
        n = len(self.capas)
        m = T.shape[0]
        for i in reversed(range(n)):
            capa = self.capas[i]
            if i == n - 1:
                capa.backward(T=T, es_salida=True)
            else:
                sig = self.capas[i + 1]
                W = sig.pesos[:-1, :] if sig.bias else sig.pesos
                capa.backward(delta_siguiente=sig.delta, W_siguiente=W)
        for c in self.capas:
            c.actualizar(alpha, m=m, l2=l2)

    def train_sgd(self, X, T, epocas, alpha, batch_size=32, tol=1e-6,
                  cada=100, X_val=None, T_val=None, l2=0.0):
        n = X.shape[0]
        loss = float("inf")
        for epoca in range(1, epocas + 1):
            idx = np.random.permutation(n)
            X_sh, T_sh = X[idx], T[idx]
            for i in range(0, n, batch_size):
                xb = X_sh[i:i + batch_size]
                tb = T_sh[i:i + batch_size]
                self.feedforward(xb)
                self.backpropagation(tb, alpha, l2=l2)

            if epoca % cada == 0 or epoca == 1:
                loss = cross_entropy(T, self.feedforward(X))
                if X_val is not None:
                    # Guardar estados para no pisarlos con la validación
                    estados = [(c.entrada_aum, c.N, c.salida) for c in self.capas]
                    YHv = self.feedforward(X_val)
                    ce_v = cross_entropy(T_val, YHv)
                    acc_v = exactitud(T_val, YHv) * 100
                    print(f"Ep {epoca:4d} | CE train: {loss:.4f} | "
                          f"CE val: {ce_v:.4f} | Acc val: {acc_v:.2f}%")
                    for c, (ea, N, s) in zip(self.capas, estados):
                        c.entrada_aum, c.N, c.salida = ea, N, s
                else:
                    print(f"Ep {epoca:4d} | CE: {loss:.4f}")

            if loss <= tol:
                print(f"Ep {epoca} | Convergió (CE={loss:.4f})")
                return
        print(f"Ep {epocas} | CE final: {loss:.4f}")

    def predecir(self, X):
        return self.feedforward(X)


# ============================================================
# CARGA DEL DATASET LIGA MX
# ============================================================
def cargar_liga_mx(nombre_archivo):
    """
    Carga el CSV de Liga MX.
    - Features: columnas 7..22 (índices 7 a 22 inclusive) = 16 columnas
    - Excluye columnas 5 y 6 (Goles_Local, Goles_Visitante) → data leakage
    - Excluye columnas 0..4 (Temporada, Jornada, Fecha, Equipo_Local, Equipo_Visitante)
    - Target: columna 24 (Target_Num). 0=L, 1=E, 2=V → one-hot
    """
    X_lista, T_lista = [], []

    with open(nombre_archivo, mode='r', encoding='utf-8') as f:
        lector = csv.reader(f)
        next(lector)  # ignorar encabezados
        for fila in lector:
            if not fila:
                continue
            # 16 features: Puntos_L5_Local ... H2H_Puntos_Visitante
            feats = [float(v) for v in fila[7:23]]
            t = int(fila[24])
            y = [0.0, 0.0, 0.0]
            y[t] = 1.0
            X_lista.append(feats)
            T_lista.append(y)

    X = np.array(X_lista, dtype=float)
    T = np.array(T_lista, dtype=float)

    # Normalización Min-Max
    X_min = X.min(axis=0)
    X_max = X.max(axis=0)
    rango = np.where(X_max - X_min == 0, 1, X_max - X_min)
    X = (X - X_min) / rango

    return X, T


# ============================================================
# BLOQUE PRINCIPAL
# ============================================================
if __name__ == "__main__":
    np.random.seed(42)

    archivo = "ligamx_dataset_red_neuronal.csv"
    X, T = cargar_liga_mx(archivo)
    print(f"Entradas: {X.shape} | Target: {T.shape}")

    # --- División train/test (70/30) ---
    n = X.shape[0]
    idx = np.random.permutation(n)
    corte = int(0.7 * n)
    X_tr, T_tr = X[idx[:corte]], T[idx[:corte]]
    X_te, T_te = X[idx[corte:]], T[idx[corte:]]

    print(f"Train: {X_tr.shape[0]} | Test: {X_te.shape[0]}")
    clases = np.argmax(T, axis=1)
    for k, nom in enumerate(["Local (L)", "Empate (E)", "Visitante (V)"]):
        print(f"  {nom}: {np.sum(clases == k)} "
              f"({100 * np.mean(clases == k):.1f}%)")

    # --- Definir red: 16 → 32 → 16 → 3 ---
    red = Red([
        Capa(entradas=16, neuronas=32, activacion=ReLu,    bias=True),
        Capa(entradas=32, neuronas=16, activacion=ReLu,    bias=True),
        Capa(entradas=16, neuronas=3,  activacion=softmax, bias=True),
    ])

    # --- Entrenamiento con mini-batch SGD ---
    red.train_sgd(
        X_tr, T_tr,
        epocas=100,
        alpha=0.5,
        batch_size=32,
        tol=1e-6,
        cada=10,
        X_val=X_te,
        T_val=T_te,
        l2=0.0,
    )

    # --- Evaluación ---
    YH_tr = red.predecir(X_tr)
    YH_te = red.predecir(X_te)

    print("\n===== MÉTRICAS FINALES =====")
    print(f"Accuracy train : {exactitud(T_tr, YH_tr) * 100:.2f}%")
    print(f"Accuracy test  : {exactitud(T_te, YH_te) * 100:.2f}%")
    print(f"CE train       : {cross_entropy(T_tr, YH_tr):.4f}")
    print(f"CE test        : {cross_entropy(T_te, YH_te):.4f}")

    # --- Matriz de confusión ---
    pred = np.argmax(YH_te, axis=1)
    real = np.argmax(T_te, axis=1)
    M = np.zeros((3, 3), dtype=int)
    for r, p in zip(real, pred):
        M[r, p] += 1

    print("\nMatriz de confusión (filas = real, cols = predicho):")
    print("             pred L   pred E   pred V")
    for k, nom in enumerate(["real L", "real E", "real V"]):
        print(f"  {nom}     {M[k,0]:6d}   {M[k,1]:6d}   {M[k,2]:6d}")

    # Diagnóstico rápido
    acc_te = exactitud(T_te, YH_te) * 100
    print("\nDiagnóstico:")
    if acc_te < 46:
        print("   Accuracy test ≤ 46% → la red no está aprendiendo.")
        print("     Prueba: sube epocas a 300, baja alpha a 0.02.")
    elif acc_te < 50:
        print("  Superó el baseline trivial (~44.5%), pero puede mejorar.")
        print("     Prueba: epocas=300, añade l2=1e-4, o más neuronas.")
    else:
        print("   Rendimiento razonable para un problema 3-clases.")
        print("     El techo realista en este dominio es ~55%.")