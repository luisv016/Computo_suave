import numpy as np
import csv
import time

# ============================================================
# ACTIVACIONES
# ============================================================
def ReLu(x):        return np.maximum(0, x)
def ReLu_deriv(x):  return (x > 0).astype(float)
def sigmoide(x):    return 1.0 / (1.0 + np.exp(-x))
def sigmoide_deriv(x):
    s = sigmoide(x); return s * (1.0 - s)
def softmax(x):
    x_s = x - np.max(x, axis=1, keepdims=True)
    e = np.exp(x_s)
    return e / np.sum(e, axis=1, keepdims=True)

DERIVADAS = {ReLu: ReLu_deriv, sigmoide: sigmoide_deriv, softmax: None}


# ============================================================
# PÉRDIDAS Y MÉTRICAS
# ============================================================
def cross_entropy(T, Yhat):
    return -np.mean(np.sum(T * np.log(Yhat + 1e-12), axis=1))

def exactitud(T, Yhat):
    return np.mean(np.argmax(Yhat, axis=1) == np.argmax(T, axis=1))


# ============================================================
# CAPA
# ============================================================
class Capa:
    def __init__(self, entradas, neuronas, activacion, bias=False, pesos=None):
        self.activacion = activacion
        self.bias = bias
        self.es_softmax = (activacion is softmax)
        if pesos is not None:
            self.pesos = np.array(pesos, dtype=float)
        else:
            filas = entradas + 1 if bias else entradas
            scale = np.sqrt(2.0 / entradas) if activacion is ReLu else np.sqrt(1.0 / entradas)
            self.pesos = np.random.randn(filas, neuronas) * scale

    def _aumentar(self, X):
        return np.hstack([X, np.ones((X.shape[0], 1))]) if self.bias else X

    def feed_forward(self, X):
        self.entrada_aum = self._aumentar(X)
        self.N = self.entrada_aum @ self.pesos
        self.salida = self.activacion(self.N)
        return self.salida

    def backward(self, T=None, delta_siguiente=None, W_siguiente=None, es_salida=False):
        if es_salida and self.es_softmax:
            self.delta = self.salida - T
        elif es_salida:
            self.delta = -(T - self.salida) * DERIVADAS[self.activacion](self.N)
        else:
            deriv = DERIVADAS[self.activacion](self.N)
            self.delta = (delta_siguiente @ W_siguiente.T) * deriv
        self.grad = self.entrada_aum.T @ self.delta
        return self.delta

    def actualizar(self, alpha, m=1, l2=0.0):
        if l2 > 0:
            self.pesos -= alpha * (self.grad / m + l2 * self.pesos)
        else:
            self.pesos -= alpha * (self.grad / m)


# ============================================================
# RED
# ============================================================
class Red:
    def __init__(self, capas):
        self.capas = capas

    def feedforward(self, X):
        a = X
        for c in self.capas: a = c.feed_forward(a)
        return a

    def backpropagation(self, T, alpha, l2=0.0):
        n = len(self.capas); m = T.shape[0]
        for i in reversed(range(n)):
            capa = self.capas[i]
            if i == n - 1:
                capa.backward(T=T, es_salida=True)
            else:
                sig = self.capas[i + 1]
                W = sig.pesos[:-1, :] if sig.bias else sig.pesos
                capa.backward(delta_siguiente=sig.delta, W_siguiente=W)
        for c in self.capas:
            c.actualizar(alpha, m=m, l2=l2)

    def train_sgd(self, X, T, epocas, alpha, batch_size=32, tol=1e-6,
                  cada=100, X_val=None, T_val=None, l2=0.0, verbose=True):
        n = X.shape[0]
        loss = float("inf")
        for epoca in range(1, epocas + 1):
            idx = np.random.permutation(n)
            X_sh, T_sh = X[idx], T[idx]
            for i in range(0, n, batch_size):
                xb = X_sh[i:i + batch_size]
                tb = T_sh[i:i + batch_size]
                self.feedforward(xb)
                self.backpropagation(tb, alpha, l2=l2)

            if verbose and (epoca % cada == 0 or epoca == 1):
                loss = cross_entropy(T, self.feedforward(X))
                if X_val is not None:
                    estados = [(c.entrada_aum, c.N, c.salida) for c in self.capas]
                    YHv = self.feedforward(X_val)
                    ce_v = cross_entropy(T_val, YHv)
                    acc_v = exactitud(T_val, YHv) * 100
                    print(f"Ep {epoca:4d} | CE tr: {loss:.4f} | "
                          f"CE val: {ce_v:.4f} | Acc val: {acc_v:.2f}%")
                    for c, (ea, N, s) in zip(self.capas, estados):
                        c.entrada_aum, c.N, c.salida = ea, N, s

    def predecir(self, X): return self.feedforward(X)


# ============================================================
# CARGA DATASET
# ============================================================
def cargar_liga_mx(nombre_archivo):
    X_lista, T_lista = [], []
    with open(nombre_archivo, mode='r', encoding='utf-8') as f:
        lector = csv.reader(f)
        next(lector)
        for fila in lector:
            if not fila: continue
            feats = [float(v) for v in fila[7:23]]
            t = int(fila[24])
            y = [0.0, 0.0, 0.0]; y[t] = 1.0
            X_lista.append(feats); T_lista.append(y)
    X = np.array(X_lista, dtype=float)
    T = np.array(T_lista, dtype=float)
    X_min, X_max = X.min(axis=0), X.max(axis=0)
    rango = np.where(X_max - X_min == 0, 1, X_max - X_min)
    X = (X - X_min) / rango
    return X, T


# ============================================================
# ALGORITMO GENÉTICO
# ============================================================
GENES = {
    "alpha":      {"min": 0.001, "max": 0.3,   "escala": "log"},
    "neuronas1":  {"min": 8,     "max": 64,    "escala": "int"},
    "neuronas2":  {"min": 4,     "max": 32,    "escala": "int"},
    "batch_size": {"min": 16,    "max": 128,   "escala": "pow2"},
    "l2":         {"min": 0.0,   "max": 1e-3,  "escala": "linear"},
}

def _clamp(v, lo, hi): return max(lo, min(hi, v))

def _opciones_pow2(spec):
    return [2**k for k in range(4, 8) if spec["min"] <= 2**k <= spec["max"]]

def gen_aleatorio(nombre):
    spec = GENES[nombre]
    if spec["escala"] == "log":
        lo, hi = np.log10(spec["min"]), np.log10(spec["max"])
        return float(10 ** np.random.uniform(lo, hi))
    if spec["escala"] == "int":
        return int(np.random.randint(spec["min"], spec["max"] + 1))
    if spec["escala"] == "pow2":
        return int(np.random.choice(_opciones_pow2(spec)))
    return float(np.random.uniform(spec["min"], spec["max"]))

def individuo_aleatorio():
    return {g: gen_aleatorio(g) for g in GENES}

def mutar(ind, prob=0.25):
    hijo = dict(ind)
    for g, spec in GENES.items():
        if np.random.rand() >= prob: continue
        if spec["escala"] == "log":
            lo, hi = np.log10(spec["min"]), np.log10(spec["max"])
            v = _clamp(np.log10(hijo[g]) + np.random.normal(0, 0.3), lo, hi)
            hijo[g] = float(10 ** v)
        elif spec["escala"] == "int":
            hijo[g] = int(_clamp(round(hijo[g] + np.random.normal(0, 3)),
                                 spec["min"], spec["max"]))
        elif spec["escala"] == "pow2":
            hijo[g] = int(np.random.choice(_opciones_pow2(spec)))
        else:
            sigma = 0.1 * (spec["max"] - spec["min"])
            hijo[g] = float(_clamp(hijo[g] + np.random.normal(0, sigma),
                                   spec["min"], spec["max"]))
    return hijo

def cruzar(p1, p2):
    return {g: (p1[g] if np.random.rand() < 0.5 else p2[g]) for g in GENES}

def torneo(poblacion, k=3):
    cand = np.random.choice(len(poblacion), k, replace=False)
    return max((poblacion[i] for i in cand),
               key=lambda i: (i["fitness"], -i["ce"]))

def firma(ind):
    return tuple(round(float(ind[g]), 6) for g in sorted(GENES))


def evaluar(ind, X_tr, T_tr, X_val, T_val, epocas):
    """Entrena una red con los genes de `ind` y devuelve (acc_val, ce_val, red)."""
    red = Red([
        Capa(16, int(ind["neuronas1"]), ReLu, True),
        Capa(int(ind["neuronas1"]), int(ind["neuronas2"]), ReLu, True),
        Capa(int(ind["neuronas2"]), 3, softmax, True),
    ])
    red.train_sgd(X_tr, T_tr, epocas=epocas, alpha=ind["alpha"],
                  batch_size=int(ind["batch_size"]), l2=ind["l2"],
                  verbose=False)
    YH = red.predecir(X_val)
    return exactitud(T_val, YH), cross_entropy(T_val, YH), red


def algoritmo_genetico(X_tr, T_tr, X_val, T_val,
                       poblacion_size=10, generaciones=12, epocas_ga=40,
                       elitismo=2, k_torneo=3, prob_mut=0.25, seed=42):
    np.random.seed(seed)
    poblacion = [individuo_aleatorio() for _ in range(poblacion_size)]
    cache = {}

    for gen in range(generaciones):
        t0 = time.time()
        # --- Evaluación ---
        for ind in poblacion:
            f = firma(ind)
            if f not in cache:
                acc, ce, _ = evaluar(ind, X_tr, T_tr, X_val, T_val, epocas_ga)
                cache[f] = (acc, ce)
            ind["fitness"], ind["ce"] = cache[f]

        poblacion.sort(key=lambda i: (i["fitness"], -i["ce"]), reverse=True)
        mejor = poblacion[0]
        dt = time.time() - t0
        print(f"Gen {gen+1:2d}/{generaciones} ({dt:4.1f}s) | "
              f"Acc val: {mejor['fitness']*100:5.2f}% | "
              f"alpha={mejor['alpha']:.4f} n1={mejor['neuronas1']:2d} "
              f"n2={mejor['neuronas2']:2d} bs={mejor['batch_size']:3d} "
              f"l2={mejor['l2']:.1e}")

        # --- Nueva generación ---
        nueva = [dict(ind) for ind in poblacion[:elitismo]]
        while len(nueva) < poblacion_size:
            p1 = torneo(poblacion, k_torneo)
            p2 = torneo(poblacion, k_torneo)
            hijo = mutar(cruzar(p1, p2), prob_mut)
            nueva.append(hijo)
        poblacion = nueva

    # Evaluar última generación completa y devolver el mejor
    for ind in poblacion:
        f = firma(ind)
        if f not in cache:
            acc, ce, _ = evaluar(ind, X_tr, T_tr, X_val, T_val, epocas_ga)
            cache[f] = (acc, ce)
        ind["fitness"], ind["ce"] = cache[f]
    poblacion.sort(key=lambda i: (i["fitness"], -i["ce"]), reverse=True)
    return poblacion[0], cache


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    np.random.seed(42)

    X, T = cargar_liga_mx("ligamx_dataset_red_neuronal.csv")
    print(f"Entradas: {X.shape} | Target: {T.shape}")

    n = X.shape[0]
    idx = np.random.permutation(n)
    corte = int(0.7 * n)
    X_tr, T_tr = X[idx[:corte]], T[idx[:corte]]
    X_te, T_te = X[idx[corte:]], T[idx[corte:]]
    print(f"Train: {X_tr.shape[0]} | Test: {X_te.shape[0]}\n")

    # ---- FASE 1: GA ----
    print("=" * 60)
    print("FASE 1 — Algoritmo genético (búsqueda de hiperparámetros)")
    print("=" * 60)
    mejor, _ = algoritmo_genetico(
        X_tr, T_tr, X_te, T_te,
        poblacion_size=10, generaciones=12, epocas_ga=40,
    )

    print("\nMejor individuo:")
    for k, v in mejor.items():
        if k in ("fitness", "ce"): continue
        print(f"  {k:12s} = {v}")
    print(f"  fitness (acc val GA) = {mejor['fitness']*100:.2f}%")

    # ---- FASE 2: Reentrenar con más épocas ----
    print("\n" + "=" * 60)
    print("FASE 2 — Reentrenamiento del mejor individuo (300 épocas)")
    print("=" * 60)
    acc_fin, ce_fin, red_fin = evaluar(mejor, X_tr, T_tr, X_te, T_te, epocas=300)

    # Métricas sobre train también
    YH_tr = red_fin.predecir(X_tr)
    acc_tr = exactitud(T_tr, YH_tr) * 100
    ce_tr  = cross_entropy(T_tr, YH_tr)

    print("\n===== MÉTRICAS FINALES =====")
    print(f"Accuracy train : {acc_tr:.2f}%")
    print(f"Accuracy test  : {acc_fin*100:.2f}%")
    print(f"CE train       : {ce_tr:.4f}")
    print(f"CE test        : {ce_fin:.4f}")

    # Matriz de confusión
    YH_te = red_fin.predecir(X_te)
    pred = np.argmax(YH_te, axis=1)
    real = np.argmax(T_te, axis=1)
    M = np.zeros((3, 3), dtype=int)
    for r, p in zip(real, pred): M[r, p] += 1

    print("\nMatriz de confusión:")
    print("             pred L   pred E   pred V")
    for k, nom in enumerate(["real L", "real E", "real V"]):
        print(f"  {nom}     {M[k,0]:6d}   {M[k,1]:6d}   {M[k,2]:6d}")