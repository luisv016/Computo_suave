import random
import copy
from typing import Dict, List

from CromosomaBin import CromosomaBinario
from interfaz import Aptitud, Seleccion, Reproduccion, Mutacion


class GA(object):
    def __init__(self, num_inv: int, num_genes: int, hyperparams: Dict):
        self.poblacion: List[CromosomaBinario] = [
            CromosomaBinario(num_genes) for _ in range(num_inv)
        ]
        self.num_inv: int = num_inv
        self.hyperparams: Dict = hyperparams
        self.evaluar: Aptitud = hyperparams["Aptitud"]
        self.seleccion: Seleccion = hyperparams["Seleccion"]
        self.reproducion: Reproduccion = hyperparams["Reproduccion"]
        self.mutacion: Mutacion = hyperparams["Mutacion"]
        self.num_remplazo = int(hyperparams["por_remplazo"] * num_inv)
        # inicializar
        for i in range(num_inv):
            self.poblacion[i].llenar_random_data()

    def buscar_solucion(self, tolerancia: float, var: Dict, max_generaciones: int = 5000):
        avg_tol: float = 99999999.99
        sum_score_prev: float = 0
        generacion: int = 1
        fail_count: int = 0
        fail_score: float = 0.0

        while True:
            self.evaluar.evaluar_poblacion(self.poblacion, var)
            sum_scores: float = sum(c.score for c in self.poblacion) / self.num_inv
            
            avg_tol = abs(sum_scores - sum_score_prev) / (sum_scores if sum_scores != 0 else 1)
            sum_score_prev = sum_scores

            if generacion % 100 == 0:
                print(f"[{generacion:04d}] avg_err: {avg_tol:.5f} avg_score: {sum_scores:.5f}")

            # heurísticas de terminación
            if avg_tol < tolerancia:
                break
            if fail_score == avg_tol:
                fail_count += 1
                if fail_count >= 10:
                    break
            if generacion >= max_generaciones:
                print(f"Se alcanzó el máximo de {max_generaciones} generaciones.")
                break
            fail_score = avg_tol

            # ordenar, seleccionar, reproducir y mutar
            self.poblacion = sorted(self.poblacion, key=lambda c: c.score, reverse=True)
            mating_pool = self.seleccion.seleccion_poblacion(self.poblacion)
            generacion_nueva = copy.deepcopy(self.poblacion[:self.num_remplazo])
            self.reproducion.reproduccion_poblacion(generacion_nueva, mating_pool, self.num_inv)
            self.mutacion.mutacion_poblacion(generacion_nueva)
            generacion += 1
            self.poblacion = generacion_nueva
        return generacion


def sum_pesos_test(pesos, cromosoma):
    s = 0
    for i in range(cromosoma.n_genes):
        if cromosoma.get_bits(i + 1) == 1:
            s += pesos[i]
    return s


if __name__ == "__main__":
    from interfaz import AptitudMochila, SeleccionTorneo, ReproduccionUnCruce, MutacionFlip

    
    PESOS = [25,2,1,2,15]          
    VALORES = [12,2,1,1,4]  
    CAPACIDAD = 35                                 

   
    CANT_IND = 100            
    PROB_MUTACION = 0.05      
    PARTICIPANTES = 3         
    POR_REMPLAZO = 0.5        
    TOLERANCIA = 1e-4
    MAX_GENERACIONES = 5000
    MOSTRAR = 10              
    SEMILLA = None            

   
    if len(PESOS) != len(VALORES):
        raise ValueError(f"PESOS tiene {len(PESOS)} elementos y VALORES {len(VALORES)}; "
                         "deben tener la misma cantidad.")
    if SEMILLA is not None:
        random.seed(SEMILLA)

    variables = {"pesos": PESOS, "valores": VALORES, "capacidad": CAPACIDAD}
    num_genes = len(PESOS)

    gaparams = {}
    gaparams["Aptitud"] = AptitudMochila()
    gaparams["Seleccion"] = SeleccionTorneo(PARTICIPANTES)
    gaparams["Reproduccion"] = ReproduccionUnCruce(num_genes)
    gaparams["Mutacion"] = MutacionFlip(PROB_MUTACION)
    gaparams["por_remplazo"] = POR_REMPLAZO

    algoritmoGA = GA(CANT_IND, num_genes, gaparams)
    gens = algoritmoGA.buscar_solucion(TOLERANCIA, variables, MAX_GENERACIONES)
    print(f"\nTerminó en la generación {gens}\n")

    solucion = sorted(algoritmoGA.poblacion, key=lambda c: c.score, reverse=True)

    print(f"{'id':^6} {'Cromosoma':^{max(num_genes, 9)}}  Score")
    for i, cromosoma in enumerate(solucion[:MOSTRAR]):
        peso = sum_pesos_test(PESOS, cromosoma)
        print(f"[{i + 1:^4d}] {cromosoma.bits:0{num_genes}b} : {cromosoma.score} -> {peso:4d} kg")

    mejor = solucion[0]
    elegidos = [i + 1 for i in range(num_genes) if mejor.get_bits(i + 1) == 1]
    print("\nMejor solución:")
    print(f"  Objetos incluidos : {elegidos}")
    print(f"  Peso total        : {sum_pesos_test(PESOS, mejor)} kg (máximo {CAPACIDAD} kg)")
    print(f"  Valor total       : {mejor.score}")
