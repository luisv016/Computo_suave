import random
from typing import Dict


class CromosomaBinario(object):
    """Cromosoma binario: cada gen es 1 bit (1 = el objeto va en la mochila).
    Los bits se guardan en un solo entero; el gen 1 es el bit de más a la izquierda.
    Funciona con cualquier número de objetos."""

    def __init__(self, genes: int):
        self.n_genes: int = genes
        self.score: int = -1
        self.gen_width: int = 1  
        self.mascaras: Dict = {}
        self.bits: int = 0
        max_value: int = 2 ** self.gen_width - 1
        for g in range(genes):
            pos = (genes - 1 - g) * self.gen_width
            self.mascaras["p" + str(g + 1)] = pos
            self.mascaras["m" + str(g + 1)] = max_value << pos

    def llenar_random_data(self):
        max_value = 2 ** self.gen_width - 1
        for i in range(self.n_genes):
            valor = random.randint(0, max_value)
            self.set_bits(valor, i + 1)

    def registrar_mascaras(self, mascara: int, gen: int) -> None:
        self.mascaras["m" + str(gen)] = mascara

    def get_bits(self, gen: int) -> int:
        return (self.bits & self.mascaras["m" + str(gen)]) >> self.mascaras["p" + str(gen)]

    def set_bits(self, valor: int, gen: int) -> None:
        self.bits = (self.bits & ~self.mascaras["m" + str(gen)]) | \
                    (valor << self.mascaras["p" + str(gen)])
