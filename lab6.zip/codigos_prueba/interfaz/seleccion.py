import random
from abc import ABC, abstractmethod
from typing import List
from CromosomaBin import CromosomaBinario


class Seleccion(ABC):
    @abstractmethod
    def seleccion_poblacion(self, poblacion: List[CromosomaBinario]) -> List[CromosomaBinario]:
        pass


class SeleccionTorneo(Seleccion):
    def __init__(self, participantes=3) -> None:
        super().__init__()
        self.participantes = participantes

    def seleccion_poblacion(self, poblacion: List[CromosomaBinario]) -> List[CromosomaBinario]:
        ganadores = []
        k = min(self.participantes, len(poblacion))
        for _ in range(len(poblacion)):
            competidores = random.sample(poblacion, k)
            ganador = max(competidores, key=lambda cromosoma: cromosoma.score)
            ganadores.append(ganador)
        return ganadores


class SeleccionRuleta(Seleccion):
    """Selecciona individuos con una probabilidad proporcional a su fitness."""

    def seleccion_poblacion(self, poblacion: List[CromosomaBinario]) -> List[CromosomaBinario]:
        if not poblacion:
            return []
        pesos = [max(0.0, cromosoma.score) for cromosoma in poblacion]
        if sum(pesos) == 0:
            return random.choices(poblacion, k=len(poblacion))
        return random.choices(poblacion, weights=pesos, k=len(poblacion))
