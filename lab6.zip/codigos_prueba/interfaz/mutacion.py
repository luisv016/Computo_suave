import random
from abc import ABC, abstractmethod
from typing import List
from CromosomaBin import CromosomaBinario


class Mutacion(ABC):
    @abstractmethod
    def mutacion_poblacion(self, poblacion: List[CromosomaBinario]):
        pass


class MutacionFlip(Mutacion):
    def __init__(self, probabilidad: float):
        super().__init__()
        self.prob = probabilidad

    def mutacion_poblacion(self, poblacion: List[CromosomaBinario]):
        max_valor = 2 ** poblacion[0].gen_width - 1
        for crom in poblacion:
            for i in range(1, crom.n_genes + 1):
                if random.random() < self.prob:
                    valor = crom.get_bits(i)
                    valor = valor ^ max_valor  
                    crom.set_bits(valor, i)


class MutacionOctal(Mutacion):
    def __init__(self, probabilidad: float):
        super().__init__()
        if not 0 <= probabilidad <= 1:
            raise ValueError("La probabilidad de mutación debe estar entre 0 y 1.")
        self.prob = probabilidad

    def mutacion_poblacion(self, poblacion: List[object]):
        for cromosoma in poblacion:
            for gen in range(1, cromosoma.n_genes + 1):
                if random.random() < self.prob:
                    cromosoma.set_bits(random.randint(0, 7), gen)


class MutacionDecimal(Mutacion):
    def __init__(self, probabilidad: float):
        super().__init__()
        if not 0 <= probabilidad <= 1:
            raise ValueError("La probabilidad de mutación debe estar entre 0 y 1.")
        self.prob = probabilidad

    def mutacion_poblacion(self, poblacion: List[object]):
        for cromosoma in poblacion:
            for gen in range(1, cromosoma.n_genes + 1):
                if random.random() < self.prob:
                    cromosoma.set_bits(
                        random.randint(1, cromosoma.procesadores), gen
                    )
