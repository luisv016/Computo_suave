from abc import ABC, abstractmethod
from typing import List, Dict
from CromosomaBin import CromosomaBinario
from CromosomaOctal import CromosomaOctal


class Aptitud(ABC):
    @abstractmethod
    def evaluar_poblacion(self, poblacion: List[CromosomaBinario], var: Dict):
        """Interfaz encargada de darle un score a la población"""
        pass


class AptitudMochila(Aptitud):
    def __init__(self, factor_penalizacion: int = 70):
        super().__init__()
        self.factor_penalizacion = factor_penalizacion

    def evaluar_poblacion(self, poblacion: List[CromosomaBinario], var: Dict):
        pesos: List[int] = var["pesos"]
        valores: List[int] = var["valores"]
        capacidad_maxima: int = var["capacidad"]
        for cromosoma in poblacion:
            peso_total = 0
            valor_total = 0
            for i in range(1, cromosoma.n_genes + 1):
                if cromosoma.get_bits(i) == 1:
                    peso_total += pesos[i - 1]
                    valor_total += valores[i - 1]
            if peso_total > capacidad_maxima:
                penalizacion = (peso_total - capacidad_maxima) * self.factor_penalizacion
                cromosoma.score = max(0, valor_total - penalizacion)
            else:
                cromosoma.score = valor_total


class AptitudOchoReinas(Aptitud):
    """Fitness de las 8 reinas: 28 menos el número de conflictos."""

    def evaluar_poblacion(self, poblacion: List[CromosomaOctal], var: Dict):
        for cromosoma in poblacion:
            conflictos = 0
            for columna_a in range(cromosoma.n_genes):
                fila_a = cromosoma.get_bits(columna_a + 1)
                for columna_b in range(columna_a + 1, cromosoma.n_genes):
                    fila_b = cromosoma.get_bits(columna_b + 1)
                    misma_fila = fila_a == fila_b
                    misma_diagonal = abs(fila_a - fila_b) == abs(columna_a - columna_b)
                    if misma_fila or misma_diagonal:
                        conflictos += 1
            cromosoma.score = 28 - conflictos


class AptitudPlanificacion(Aptitud):
    """Fitness = 1 / (1 + carga máxima entre los procesadores)."""

    def evaluar_poblacion(self, poblacion, var: Dict):
        tiempos = var["tiempos"]
        procesadores = var.get("procesadores", 3)
        if len(tiempos) == 0:
            raise ValueError("La lista de tiempos no puede estar vacía.")
        if any(tiempo < 0 for tiempo in tiempos):
            raise ValueError("Los tiempos de ejecución no pueden ser negativos.")

        for cromosoma in poblacion:
            if cromosoma.n_genes != len(tiempos):
                raise ValueError(
                    "La cantidad de genes debe coincidir con la cantidad de tareas."
                )
            cargas = [0] * procesadores
            for tarea, tiempo in enumerate(tiempos, start=1):
                procesador = cromosoma.get_bits(tarea)
                if not 1 <= procesador <= procesadores:
                    raise ValueError("Cada gen debe indicar un procesador válido.")
                cargas[procesador - 1] += tiempo
            cromosoma.cargas = cargas
            cromosoma.carga_maxima = max(cargas)
            cromosoma.score = 1 / (1 + cromosoma.carga_maxima)
