import random

from CromosomaOctal import CromosomaOctal
from GAbin import GA
from interfaz import (
    AptitudOchoReinas,
    MutacionOctal,
    ReproduccionUnCruce,
    SeleccionTorneo,
)


def mostrar_tablero(cromosoma: CromosomaOctal):
    return "\n".join(
        " ".join(
            "Q" if cromosoma.get_bits(columna + 1) == fila else "."
            for columna in range(8)
        )
        for fila in range(8)
    )


if __name__ == "__main__":
    random.seed(42)

    cantidad_individuos = 100
    probabilidad_mutacion = 0.05
    porcentaje_reemplazo = 0.5
    max_generaciones = 5000

    parametros = {
        "Aptitud": AptitudOchoReinas(),
        "Seleccion": SeleccionTorneo(participantes=3),
        "Reproduccion": ReproduccionUnCruce(8, cromosoma_cls=CromosomaOctal),
        "Mutacion": MutacionOctal(probabilidad_mutacion),
        "por_remplazo": porcentaje_reemplazo,
    }

    algoritmo = GA(
        cantidad_individuos,
        8,
        parametros,
        cromosoma_cls=CromosomaOctal,
    )
    generaciones = algoritmo.buscar_solucion(
        tolerancia=0,
        var={},
        max_generaciones=max_generaciones,
        score_objetivo=28,
    )

    mejor = max(algoritmo.poblacion, key=lambda cromosoma: cromosoma.score)
    print(f"Generaciones: {generaciones}")
    print(f"Cromosoma octal: {mejor.octal}")
    print(f"Fitness: {mejor.score}/28")
    print(mostrar_tablero(mejor))
