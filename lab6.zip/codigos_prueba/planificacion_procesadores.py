import random

from CromosomaDecimal import CromosomaDecimal
from GAbin import GA
from interfaz import (
    AptitudPlanificacion,
    MutacionDecimal,
    ReproduccionUnCruce,
    SeleccionRuleta,
)


TIEMPOS = [8, 5, 7, 3, 6, 4]
PROCESADORES = 3


def mostrar_asignacion(cromosoma: CromosomaDecimal, tiempos):
    cargas = [[] for _ in range(cromosoma.procesadores)]
    for tarea, procesador in enumerate(cromosoma.genes, start=1):
        cargas[procesador - 1].append(f"T{tarea}")
    return "\n".join(
        f"P{numero}: {', '.join(tareas) or '(sin tareas)'} | "
        f"Tiempo: {cromosoma.cargas[numero - 1]}"
        for numero, tareas in enumerate(cargas, start=1)
    )


if __name__ == "__main__":
    random.seed(42)

    parametros = {
        "Aptitud": AptitudPlanificacion(),
        "Seleccion": SeleccionRuleta(),
        "Reproduccion": ReproduccionUnCruce(
            len(TIEMPOS), cromosoma_cls=CromosomaDecimal
        ),
        "Mutacion": MutacionDecimal(probabilidad=0.05),
        "por_remplazo": 0.5,
    }
    algoritmo = GA(
        num_inv=100,
        num_genes=len(TIEMPOS),
        hyperparams=parametros,
        cromosoma_cls=CromosomaDecimal,
    )
    objetivo = 1 / (1 + 11)
    generaciones = algoritmo.buscar_solucion(
        tolerancia=0,
        var={"tiempos": TIEMPOS, "procesadores": PROCESADORES},
        max_generaciones=5000,
        score_objetivo=objetivo,
    )

    mejor = max(algoritmo.poblacion, key=lambda cromosoma: cromosoma.score)
    print(f"Generaciones: {generaciones}")
    print(f"Cromosoma decimal: {mejor.decimal}")
    print(f"Fitness: {mejor.score:.6f}")
    print(mostrar_asignacion(mejor, TIEMPOS))
