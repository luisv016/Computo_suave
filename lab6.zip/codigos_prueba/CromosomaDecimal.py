import random


class CromosomaDecimal:
    """Cromosoma de asignación: cada gen indica un procesador (1, 2 o 3)."""

    def __init__(self, genes: int = 6, procesadores: int = 3):
        if genes <= 0:
            raise ValueError("El cromosoma debe tener al menos un gen.")
        if procesadores <= 0:
            raise ValueError("Debe existir al menos un procesador.")
        self.n_genes = genes
        self.procesadores = procesadores
        self.gen_width = 1
        self.score = -1.0
        self.genes = [1] * genes

    def llenar_random_data(self):
        self.genes = [
            random.randint(1, self.procesadores) for _ in range(self.n_genes)
        ]

    def get_bits(self, gen: int) -> int:
        if not 1 <= gen <= self.n_genes:
            raise IndexError(f"El gen debe estar entre 1 y {self.n_genes}.")
        return self.genes[gen - 1]

    def set_bits(self, valor: int, gen: int):
        if not 1 <= gen <= self.n_genes:
            raise IndexError(f"El gen debe estar entre 1 y {self.n_genes}.")
        if not 1 <= valor <= self.procesadores:
            raise ValueError(
                f"Un gen decimal debe indicar un procesador entre 1 y "
                f"{self.procesadores}."
            )
        self.genes[gen - 1] = valor

    @property
    def decimal(self) -> str:
        return "".join(str(valor) for valor in self.genes)
