import random


class CromosomaOctal:
    """Cromosoma de ocho genes; cada gen representa una fila de 0 a 7."""

    def __init__(self, genes: int = 8):
        if genes != 8:
            raise ValueError("El problema de las 8 reinas requiere exactamente 8 genes.")
        self.n_genes = genes
        self.gen_width = 3
        self.score = -1
        self.genes = [0] * genes

    def llenar_random_data(self):
        self.genes = [random.randint(0, 7) for _ in range(self.n_genes)]

    def get_bits(self, gen: int) -> int:
        """Conserva la misma interfaz del cromosoma binario."""
        if not 1 <= gen <= self.n_genes:
            raise IndexError(f"El gen debe estar entre 1 y {self.n_genes}.")
        return self.genes[gen - 1]

    def set_bits(self, valor: int, gen: int):
        if not 1 <= gen <= self.n_genes:
            raise IndexError(f"El gen debe estar entre 1 y {self.n_genes}.")
        if not 0 <= valor <= 7:
            raise ValueError("Un gen octal solo puede tomar valores de 0 a 7.")
        self.genes[gen - 1] = valor

    @property
    def octal(self) -> str:
        return "".join(str(valor) for valor in self.genes)
